use python3

Link : https://www.python.org/downloads/release/python-3912/

don't forget to install this
requests, bs4, colorama

code:
python -m pip install requests && python -m pip install bs4 && python -m pip install colorama

shell pass:
# wp_wrong_datlib.php | stusa
# xm.php | xleet
# 4x4.php | mravast
# sys.php | sys123
# wp.php | 12qwaszx
# xleet.php | xleet
# 404.php | admin or G00DV1N
# 23.php = AnonymousFox
# Ninja.php = IndexAttacker
# Mo2aaPriv.php = Mo2a0123
# wp_logx.php =
# ffAA531.php = root
# wpse.php = leksak98@
# _.php = root
# mailer.php = kpxwbYBP4hQK
# wp-admin-configs.php = root
# wp-contentt.php = asdsdggenu
# wp-content/5.php = kontolgaceng
# likeyou.php | kontolcokasu