<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="SHORTCUT ICON" href="http://l.yimg.com/us.yimg.com/i/mesg/emoticons7/66.gif" type="image">
<style type="text/css">
body{
	background-color:#000000;
	color:#f1f1f1;
	color:#00FF00;
	}
button{
	border:#999999 1px solid;
	color:#000000;
	}
p{
	font-family:"Courier New",Arial, "Lucida console";
	font-size:12px;
	}
</style>
<script src="https://code.jquery.com/jquery-1.5.min.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){
	$("#show").click(function(){
	$(".hilang").toggle('slow');
	});
});
</script>
	
</script>
<title>-X ops! pwned By Black_X12 ft Yanagi_X12 X-</title>
</head>
<body>
	<h1> pwned By Black_X12 ft Yanagi_X12</h1>
<pre>


Thanks to :
Clan_X12
</pre>
<pre>
Greatz : Black_X12
</pre>

<a href="#" id="show" style="text-decoration:none; color:#FF0000; font-size:20px; font-weight:bold;">
Want a Bonus? Please click this!</a>

<pre style="display:none;" class="hilang">
[root@<?= "{$_SERVER["SERVER_NAME"]}"; ?>]$  ls -l
total 321
drwxr-xr-x 11 root:L7 4096 Feb  4 08:37 ./
drwx--x--x  8 root:L7 4096 Apr 29  2010 ../
-rw-r--r--  1 root:L7  545 Jan 11 21:40 .htaccess
drwxr-xr-x  2 root:L7 4096 Feb  4 08:37 cgi-bin/
-rw-r--r--  1 root:L7  397 Dec 30 03:34 index.php
-rw-r--r--  1 root:L7 15410 Dec 30 03:34 license.txt
-rw-r--r--  1 root:L7 9120 Dec 30 03:34 readme.html
-rw-r--r--  1 root:L7 4391 Dec 30 03:34 wp-activate.php
drwxr-xr-x  7 root:L7 4096 Jun 25  2010 wp-admin/
-rw-r--r--  1 root:L7  274 Dec 30 03:35 wp-blog-header.php
-rw-r--r--  1 root:L7 3926 Dec 30 03:35 wp-comments-post.php
-rw-r--r--  1 root:L7  238 Dec 30 03:35 wp-commentsrss2.php
-rw-r--r--  1 root:L7 3173 Dec 30 03:35 wp-config-sample.php
-rw-r--r--  1 root:L7 3368 Jun 25  2010 wp-config.php
drwxr-xr-x  6 root:L7 4096 Feb  4 08:29 wp-content/
-rw-r--r--  1 root:L7 1255 Dec 30 03:35 wp-cron.php
-rw-r--r--  1 root:L7  240 Dec 30 03:35 wp-feed.php
drwxr-xr-x  7 root:L7 4096 Jun 25  2010 wp-includes/
-rw-r--r--  1 root:L7 2002 Dec 30 03:37 wp-links-opml.php
-rw-r--r--  1 root:L7 2441 Dec 30 03:37 wp-load.php
-rw-r--r--  1 root:L7 26353 Feb  3 21:47 wp-login.php
-rw-r--r--  1 root:L7 7774 Dec 30 03:37 wp-mail.php
-rw-r--r--  1 root:L7  487 Dec 30 03:37 wp-pass.php
-rw-r--r--  1 root:L7  218 Dec 30 03:37 wp-rdf.php
-rw-r--r--  1 root:L7  316 Dec 30 03:37 wp-register.php
-rw-r--r--  1 root:L7  218 Dec 30 03:37 wp-rss.php
-rw-r--r--  1 root:L7  220 Dec 30 03:37 wp-rss2.php
-rw-r--r--  1 root:L7 9177 Dec 30 03:37 wp-settings.php
-rw-r--r--  1 root:L7 18695 Dec 30 03:37 wp-signup.php
-rw-r--r--  1 root:L7 3702 Dec 30 03:37 wp-trackback.php
-rw-r--r--  1 root:L7 95481 Dec 30 03:37 xmlrpc.php
</pre>
</body>
</html>
